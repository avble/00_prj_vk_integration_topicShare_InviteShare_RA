/******************************************************************************
 * Copyright (c) 2014, VEriK Systems. All rights reserved.
 *
 * Module: Service Provider
 *
 ******************************************************************************/


#include "ubus_service.h"

int init_ubus_service(struct ubus_context **ctx)
{
    const char *ubus_socket = NULL;

    uloop_init();

    *ctx = ubus_connect(ubus_socket);
    if (!*ctx) {
        fprintf(stderr, "Failed to connect to ubus\n");
        return -1;
    }

    ubus_add_uloop(*ctx);

    return 0;
}

void client_main(struct ubus_context **ctx, struct ubus_object *main_object, struct ubus_subscriber *main_event)
{ 
    int ret;

    // FIXME: what happens if the remote.access has alread existed 
    ret = ubus_add_object(*ctx, main_object);
    if (ret) {
        fprintf(stderr, "Failed to add_object object: %s\n", ubus_strerror(ret));
        return;
    }

    ret = ubus_register_subscriber(*ctx, main_event);
    if (ret)
        fprintf(stderr, "Failed to add watch handler: %s\n", ubus_strerror(ret));

    uloop_run();
}

void free_ubus_service(struct ubus_context **ctx)
{
    ubus_free(*ctx);
    uloop_done();

    // if(buff.buf)
    // {
    //     free(buff.buf);
    // }
}

