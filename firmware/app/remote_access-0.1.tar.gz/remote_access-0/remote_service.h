/******************************************************************************
 * Copyright (c) 2014, VEriK Systems. All rights reserved.
 *
 * Module: Remote Service
 *
 ******************************************************************************/


#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <json-c/json.h>
#include <uci.h>

#include <mosquitto.h>

//json information
#define METHOD "method"
#define TYPE "type"
#define NODE_ID "NodeID"
#define ID "id"
#define EPNUM "epnum"
#define PROID "proid"
#define VALUE "value"


 struct mosquitto *mosq;
 
 void connect_callback(struct mosquitto *mosq, void *obj, int result);

 void message_callback(struct mosquitto *mosq, void *obj, const struct mosquitto_message *message);

 void start_service(void);