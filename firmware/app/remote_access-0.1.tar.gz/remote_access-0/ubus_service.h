/******************************************************************************
 * Copyright (c) 2014, VEriK Systems. All rights reserved.
 *
 * Module: Service Provider
 *
 ******************************************************************************/

#include <libubus.h>
#include <libubox/blobmsg_json.h>

typedef struct _daemon_service 
{
    const char *name;
    uint32_t obj_id;
    uint32_t id;
} daemon_service;

enum {
    NOTIFY_ID,
    SERVICE_NAME,
    __NOTIFY_MAX
};

enum {
	NOTIFY_SERVICE,
	NOTIFY_MSG,
	__NOTIFY_SIZE
};

int init_ubus_service(struct ubus_context **ctx);

void client_main(struct ubus_context **ctx, struct ubus_object *main_object, struct ubus_subscriber *main_event);

void free_ubus_service(struct ubus_context **ctx);

