/******************************************************************************
 * Copyright (c) 2014, VEriK Systems. All rights reserved.
 *
 * Module: Remote Service
 *
 ******************************************************************************/
// FIXME: 
// Refactory the source code for the following reasonale 
 // + As per discussion, just one topic is used for sub/pub. Therefore, It would be nonsense if we are receive the message, which is just published 
 //   An uuid field is added to identify ...... UUID's representation should be 32 byte. E.g. 123e4567-e89b-12d3-a456-426655440000
 // + 

#include "remote_service.h"
#include "ubus_service.h"
#include "slog.h"



typedef struct remote_service_s{
	char uuid[33];
	char topic[256];

}remote_service_t;

remote_service_t g_remote_sevice;


 static int run = 1;

 static struct ubus_context *ctx;
 static struct ubus_subscriber main_event;
 static struct blob_buf buff;
 static struct ubus_request g_req;

 daemon_service daemon_services[] = {
 	{"zigbee",            0},
 	{"zwave",             0},
 	{"upnp",              0},
 };

 static const struct blobmsg_policy msg_policy[1] = {
 	[0] = { .name = "msg", .type = BLOBMSG_TYPE_STRING },
 };


 static const struct blobmsg_policy register_notify_policy[__NOTIFY_MAX] = {
 	[NOTIFY_ID] = { .name = "notify_id", .type = BLOBMSG_TYPE_INT32 },
 	[SERVICE_NAME] = { .name = "service_name", .type = BLOBMSG_TYPE_STRING },
 };

 static const struct blobmsg_policy notify_policy[__NOTIFY_SIZE] = {
 	[NOTIFY_SERVICE] = { .name = "service_name", .type = BLOBMSG_TYPE_STRING },
 	[NOTIFY_MSG] = { .name = "notify_message", .type = BLOBMSG_TYPE_STRING },
 };


static void read_config(const char *path, char const * in_key, char *in_value)
{
    FILE *file = fopen(path, "r");
    printf("DEBUG %s %d \n", __FILE__, __LINE__);
    if (file == NULL)
	{
		printf("[DEBUG] %s %d Can not open file: %s \n", __FILE__, __LINE__, path);
        return; 
	}

	printf("DEBUG %s %d \n", __FILE__, __LINE__);


    while (!feof(file))
    {   
        char key[256];
        char value[256];
        char line[256];

        bzero(key, sizeof(key));
        bzero(value, sizeof(value));
        bzero(line, sizeof(line));

        if (fgets(line, sizeof(line), file) == NULL)
            continue; 

        if (line[0] == '#' || line[0] == ' ' || line[0] == 10) 
            continue; 

        sscanf(line,  "%s %s", key, value);

        if (strcmp(key, in_key) == 0)
        {   
            strcpy(in_value, value);
        }

        printf("[Debug] key: %s, value: %s \n",  key, value);
    
    }   
    fclose(file);
}


void remote_service_init()
{
	// FIXME: it should be dynamically generated 
	strcpy(g_remote_sevice.uuid, "123e4567-e89b-12d3-a456-426655440000");
	printf("DEBUG %s %d \n", __FILE__, __LINE__);
	read_config("/etc/alljoyn_topic", "topic", g_remote_sevice.topic);

}



 static char* read_option(const char* option)
 {
 	struct uci_context *ctx;
	struct uci_ptr ptr;
	int ret;
	char* data;

	char *input = strdup(option);

	ctx = uci_alloc_context();
	if (!ctx)
	{
		printf("Failed to alloc uci_context.\n");
		return data;
	}

	ret = uci_lookup_ptr(ctx, &ptr, input, TRUE);

	if(ret == UCI_OK)
	{
		data = strdup(ptr.o->v.string);
		uci_free_context(ctx);
		free(input);
	}

	return data;
 }

 static void notify_handle_remove(struct ubus_context *ctx, struct ubus_subscriber *s, uint32_t id)
 {
 	fprintf(stderr, "Object %08x went away\n", id);
 	int i;
 	for (i = 0; i < sizeof(daemon_services)/sizeof(daemon_service); i++) 
 	{
 		if (daemon_services[i].obj_id == id)
 		{
 			printf("removing id and obj_id\n");
 			daemon_services[i].id = 0;
 			daemon_services[i].obj_id = 0;
 		}
 	}
 }

 static int recive_notify_cb(struct ubus_context *ctx, struct ubus_object *obj,
 	struct ubus_request_data *req, const char *method,
 	struct blob_attr *msg)
 {
 	printf("recive_notify_cb \n");
 	const char *msgstr = "(unknown)";
 	struct blob_attr *tb[1];
 	blobmsg_parse(msg_policy, ARRAY_SIZE(msg_policy), tb, blob_data(msg), blob_len(msg));

 	if (tb[0])
 	{
 		msgstr = blobmsg_data(tb[0]);
 		printf("msgstr =%s\n", msgstr);
 	}

 	return 0;
 }

 static int register_notify(struct ubus_context *ctx, struct ubus_object *obj,
 	struct ubus_request_data *req, const char *method,
 	struct blob_attr *msg)
 {
 	struct blob_attr *tb[__NOTIFY_MAX];
 	int i;
 	int ret;

 	blobmsg_parse(register_notify_policy, __NOTIFY_MAX, tb, blob_data(msg), blob_len(msg));
 	if (!tb[NOTIFY_ID] || !tb[SERVICE_NAME])
 	{
 		fprintf(stderr, "Register notify need both notify id and service name\n");
 		return UBUS_STATUS_INVALID_ARGUMENT;
 	}

 	main_event.remove_cb = notify_handle_remove;
 	main_event.cb = recive_notify_cb;
 	ret = ubus_subscribe(ctx, &main_event, blobmsg_get_u32(tb[NOTIFY_ID]));
 	fprintf(stderr, "Watching object %08x: %s\n", blobmsg_get_u32(tb[NOTIFY_ID]), ubus_strerror(ret));

 	if(!ret)
 	{
 		for (i = 0; i < sizeof(daemon_services)/sizeof(daemon_service); i++) 
 		{
 			if (!strcmp (daemon_services[i].name, (char *)blobmsg_data(tb[SERVICE_NAME]))) 
 			{
 				if(ubus_lookup_id(ctx, blobmsg_data(tb[SERVICE_NAME]), &daemon_services[i].id)) 
                { //find service handler
                	fprintf(stderr, "Failed to look up %s object\n", (char*)blobmsg_data(tb[SERVICE_NAME]));
                	return ret;
                }
                else
                {
                	daemon_services[i].obj_id = blobmsg_get_u32(tb[NOTIFY_ID]);
                	printf("Success to look up %s object\n", (char*)blobmsg_data(tb[SERVICE_NAME]));
                	break;
                }
            }
        }
    }
    return ret;
}

static int notify(struct ubus_context *ctx, struct ubus_object *obj,
	struct ubus_request_data *req, const char* method,
	struct blob_attr *msg)
{
	struct blob_attr *tb[__NOTIFY_MAX];
	printf("Recieved notify message.\n");

	blobmsg_parse(notify_policy, __NOTIFY_MAX, tb, blob_data(msg), blob_len(msg));
	if (!tb[SERVICE_NAME] || !tb[NOTIFY_MSG])
	{
		printf("Notify message lack of information.\n");
		return UBUS_STATUS_INVALID_ARGUMENT;
	}

	//set callback handler
	main_event.cb = recive_notify_cb;

	//retrieve message
	//char* service_name = (char *)blobmsg_data(tb[SERVICE_NAME]);
	char* message = (char *)blobmsg_data(tb[NOTIFY_MSG]);

	//publish message
	if(mosq)
	{
	//	char* topic = read_option("remote.access.notify");
		printf("Notify to topic = %s with message = %s\n", g_remote_sevice.topic, message);
		int rs = mosquitto_publish(mosq, NULL, g_remote_sevice.topic, strlen(message), (const void *)message, 0, 0);
		printf("Publish message with result = %d\n", rs);
		//free(topic);
		return rs;
	}

	return -1;
}

static const struct ubus_method main_methods[] = {
	UBUS_METHOD("register_notify", register_notify, register_notify_policy),
	UBUS_METHOD("notify", notify, notify_policy),
};

static struct ubus_object_type main_object_type =
UBUS_OBJECT_TYPE("remote.access", main_methods);

static struct ubus_object main_object = {
	.name = "remote.access",
	.type = &main_object_type,
	.methods = main_methods,
	.n_methods = ARRAY_SIZE(main_methods),
};

void handle_signal(int s)
{
	run = 0;

	if (s == 2)
	{
		//clean up
		mosquitto_loop_stop(mosq,1);
		free_ubus_service(&ctx);
		mosquitto_destroy(mosq);
		mosquitto_lib_cleanup();
		exit(1);
	}
}


static void complete_cb(struct ubus_request *req, int ret)
{
	printf("Completed request, result: %d\n", ret);
}


// 
static void recive_data_cb(struct ubus_request *req, int type, struct blob_attr *msg)
{
	printf("receive msg from ubus\n");
	const char *msgstr = "(unknown)";
	struct blob_attr *tb[__NOTIFY_MAX];
	blobmsg_parse(msg_policy, ARRAY_SIZE(msg_policy), tb, blob_data(msg), blob_len(msg));

	if (tb[0])
	{
		msgstr = blobmsg_data(tb[0]);
	}

	//FIXME: hard-code for debugging 
	strcpy(msgstr, "{\"type\":\"zwave\",\"method\":\"list_devicesR\",\"uuid\":\"a1189345-2efa-466f-8291-e7ebf052bc2b\"}");
	// 
	printf("msgstr = %s\n", msgstr);
	
	if(mosq)
	{
		//char* topic = read_option("remote.access.notify");
		printf("Notify to topic = %s with message = %s\n", g_remote_sevice.topic, msgstr);
		int rs = mosquitto_publish(mosq, NULL, g_remote_sevice.topic, strlen(msgstr), (const void *)msgstr, 0, 0);
		printf("Publish message with result = %d\n", rs);
		//free(topic);
	}
}

static char * get_string_data(const char * message, const char * name){

	/* convert json message to json object */
	json_object * jobj = json_tokener_parse(message);

	if (jobj == NULL)
		return NULL;

	/* scan json object */
	json_object_object_foreach(jobj, key, val)
	{
		if(!strcmp(key,name)) {
			return (char*) json_object_get_string(val);
		}

	}
	return NULL;
}

void connect_callback(struct mosquitto *mosq, void *obj, int result)
{
	printf("Connection callbacked with result = %d.\n", result);
}

void message_callback(struct mosquitto *mosq, void *obj, const struct mosquitto_message *message)
{
	int u_ret;
	uint32_t id;
	int msg_len = message->payloadlen;
	char buffer[msg_len];
	strcpy(buffer, message->payload);
	const char* msg = buffer;

	printf("Message recieved: %s\n", msg);

	//parsing message
	char * method = get_string_data(msg,METHOD);
	if (method == NULL)
	{
		printf("[DEBUG] %s, %d It is does not has METHOD \n", __FUNCTION__, __LINE__);
		return;
	}
	char* type = get_string_data(msg,TYPE);
	if (type == NULL)
	{
		printf("[DEBUG] %s, %d It is does not has TYPE \n", __FUNCTION__, __LINE__);
		return;
	}

	printf("[DEBUG] method: %s --- type: %s \n", method, type);

	if (!strcmp(method,"add_devices"))
	{
		//call ubus to add device
		if (!strcmp(type,"zigbee"))
		{
			//Not support add a new zigbee device via ubus service
			printf("Not support add a new zigbee device via ubus service.\n");
		}
		else if (!strcmp(type,"zwave"))
		{
			//call ubus mehod to add new z-wave device
			if (daemon_services[1].id != 0)
			{
				printf("Start to add a new z-wave device.\n");
				ubus_invoke_async(ctx, daemon_services[1].id, "add_devices", NULL, &g_req);
				g_req.data_cb = recive_data_cb;
				g_req.complete_cb = complete_cb;
				ubus_complete_request_async(ctx, &g_req);
			}
			else
			{
				//cannot find zigbee ubus service to call
				printf("Cannot find zwave service on ubus daemon.\n");
			}
		}
		else if (!strcmp(type,"upnp"))
		{
			//call ubus method to add new upnp device
			if(daemon_services[2].id != 0)
			{
				printf("Start to add a new upnp device.\n");
				ubus_invoke_async(ctx, daemon_services[2].id, "add_devices", NULL, &g_req);
				g_req.data_cb = recive_data_cb;
				g_req.complete_cb = complete_cb;
				ubus_complete_request_async(ctx, &g_req);
			}
			else
			{
				//cannot find upnp ubus service to call
				printf("Cannot find upnp service on ubus daemon.\n");
			}
		}
		else
		{
			//service is not supported
			printf("Serivce %s is currently not supported.\n", type);	
		}
	}
	else if (!strcmp(method,"remove_device"))
	{
		//call ubus to remove device
		if (!strcmp(type,"zigbee"))
		{
			//call ubus mehod to remove a zigbee device
			if(daemon_services[0].id != 0)
			{
				char* nodeID = get_string_data(msg,NODE_ID);
				printf("Start to remove a zigbee device with nodeID = %s\n", nodeID);
				blob_buf_init(&buff, 0);
				blobmsg_add_string(&buff, NODE_ID, nodeID);
				ubus_invoke_async(ctx, daemon_services[0].id, "remove_device", buff.head, &g_req);
				g_req.data_cb = recive_data_cb;
				g_req.complete_cb = complete_cb;
				ubus_complete_request_async(ctx, &g_req);
			}
			else
			{
				//cannot find zigbee ubus service to call
				printf("Cannot find zigbee service on ubus daemon.\n");
			}
		}
		else if (!strcmp(type,"zwave"))
		{
			//call ubus mehod to remove a z-wave device
			if (daemon_services[1].id != 0)
			{
				printf("Start to remove a z-wave device.\n");
				ubus_invoke_async(ctx, daemon_services[1].id, "remove_device", NULL, &g_req);
				g_req.data_cb = recive_data_cb;
				g_req.complete_cb = complete_cb;
				ubus_complete_request_async(ctx, &g_req);
			}
			else
			{
				//cannot find zigbee ubus service to call
				printf("Cannot find zwave service on ubus daemon.\n");
			}
		}
		else if (!strcmp(type,"upnp"))
		{
			//Not support remove a upnp device via ubus service
			printf("Not support remove a upnp device via ubus service.\n");
		}
		else
		{
			//service is not supported
			printf("Serivce %s is currently not supported.\n", type);
		}
	}
	else if (!strcmp(method,"list_devices"))
	{
		//call ubus to list devices
		if (!strcmp(type,"zigbee"))
		{
			//call ubus mehod to list zigbee devices
			if(daemon_services[0].id != 0)
			{
				printf("Start to list zigbee devices.\n");
				ubus_invoke_async(ctx, daemon_services[0].id, "list_devices", NULL, &g_req);
				g_req.data_cb = recive_data_cb;
				g_req.complete_cb = complete_cb;
				ubus_complete_request_async(ctx, &g_req);
			}
			else
			{
				//cannot find zigbee ubus service to call
				printf("Cannot find zigbee service on ubus daemon.\n");
			}
		}
		else if (!strcmp(type,"zwave"))
		{
			//call ubus mehod to list z-wave devices
			if (daemon_services[1].id != 0)
			{
				printf("Start to list z-wave devices.\n");
				ubus_invoke_async(ctx, daemon_services[1].id, "list_devices", NULL, &g_req);
				g_req.data_cb = recive_data_cb;
				g_req.complete_cb = complete_cb;
				ubus_complete_request_async(ctx, &g_req);
			}
			else
			{
				//cannot find zigbee ubus service to call
				printf("Cannot find zwave service on ubus daemon.\n");
			}
		}
		else if (!strcmp(type,"upnp"))
		{
			if(daemon_services[2].id != 0)
			{
				printf("Start to list upnp devices.\n");
				ubus_invoke_async(ctx, daemon_services[2].id, "list_devices", NULL, &g_req);
				g_req.data_cb = recive_data_cb;
				g_req.complete_cb = complete_cb;
				ubus_complete_request_async(ctx, &g_req);
			}
			else
			{
				//cannot find upnp ubus service to call
				printf("Cannot find upnp service on ubus daemon.\n");
			}
		}
		else
		{
			//service is not supported
			printf("Serivce %s is currently not supported.\n", type);
		}
	}
	else if (!strcmp(method,"set_binary"))
	{
		//call ubus to set binary
		if (!strcmp(type,"zigbee"))
		{
			//call ubus mehod to set binary for a zigbee device
			if(daemon_services[0].id != 0)
			{
				char* id = get_string_data(msg,ID);
				char* epnum = get_string_data(msg,EPNUM);
				char* proid = get_string_data(msg,PROID);
				char* value = get_string_data(msg,VALUE);
				printf("Start to set_binary for zigbee device with id = %s.\n",id);
				blob_buf_init(&buff, 0);
				blobmsg_add_string(&buff, ID, id);
				blobmsg_add_string(&buff, EPNUM, epnum);
				blobmsg_add_string(&buff, PROID, proid);
				blobmsg_add_string(&buff, VALUE, value);
				ubus_invoke_async(ctx, daemon_services[0].id, "set_binary", buff.head, &g_req);
				g_req.data_cb = recive_data_cb;
				g_req.complete_cb = complete_cb;
				ubus_complete_request_async(ctx, &g_req);
			}
			else
			{
				//cannot find zigbee ubus service to call
				printf("Cannot find zigbee service on ubus daemon.\n");
			}
		}
		else if (!strcmp(type,"zwave"))
		{
			//call ubus mehod to set binary for a z-wave device
			if(daemon_services[1].id != 0)
			{
				char* id = get_string_data(msg,ID);
				char* value = get_string_data(msg,VALUE);
				printf("Start to set_binary for z-wave device with id = %s.\n",id);
				blob_buf_init(&buff, 0);
				blobmsg_add_string(&buff, ID, id);
				blobmsg_add_string(&buff, VALUE, value);
				ubus_invoke_async(ctx, daemon_services[1].id, "set_binary", buff.head, &g_req);
				g_req.data_cb = recive_data_cb;
				g_req.complete_cb = complete_cb;
				ubus_complete_request_async(ctx, &g_req);
			}
			else
			{
				//cannot find zigbee ubus service to call
				printf("Cannot find zwave service on ubus daemon.\n");	
			}
		}
		else if (!strcmp(type,"upnp"))
		{
			if(daemon_services[2].id != 0)
			{
				char* id = get_string_data(msg,ID);
				char* value = get_string_data(msg,VALUE);
				printf("Start to set_binary for upnp device with id = %s.\n",id);
				blob_buf_init(&buff, 0);
				blobmsg_add_string(&buff, ID, id);
				blobmsg_add_string(&buff, VALUE, value);
				ubus_invoke_async(ctx, daemon_services[2].id, "set_binary", buff.head, &g_req);
				g_req.data_cb = recive_data_cb;
				g_req.complete_cb = complete_cb;
				ubus_complete_request_async(ctx, &g_req);
			}
			else
			{
				//cannot find upnp ubus service to call
				printf("Cannot find upnp service on ubus daemon.\n");
			}
		}
		else
		{
			//service is not supported
			printf("Serivce %s is currently not supported.\n", type);
		}
	}
	else if (!strcmp(method,"set_dimmer"))
	{
		//call ubus to set dimmer
		if (!strcmp(type,"zigbee"))
		{
			//call ubus mehod to set binary for a zigbee device
			if(daemon_services[0].id != 0)
			{
				char* id = get_string_data(msg,ID);
				char* epnum = get_string_data(msg,EPNUM);
				char* proid = get_string_data(msg,PROID);
				char* value = get_string_data(msg,VALUE);
				printf("Start to set dimmer for zigbee device with id =%s.\n",id);
				blob_buf_init(&buff, 0);
				blobmsg_add_string(&buff, ID, id);
				blobmsg_add_string(&buff, EPNUM, epnum);
				blobmsg_add_string(&buff, PROID, proid);
				blobmsg_add_string(&buff, VALUE, value);
				ubus_invoke_async(ctx, daemon_services[0].id, "set_dimmer", buff.head, &g_req);
				g_req.data_cb = recive_data_cb;
				g_req.complete_cb = complete_cb;
				ubus_complete_request_async(ctx, &g_req);
			}
			else
			{
				//cannot find zigbee ubus service to call
				printf("Cannot find zigbee service on ubus daemon.\n");
			}
		}
		else if (!strcmp(type,"zwave"))
		{
			//call ubus mehod to set dimmer for a z-wave device
			printf("Currently not supported set dimmer for z-wave device\n");
		}
		else if (!strcmp(type,"upnp"))
		{
			//Not support set dimmer a upnp device via ubus service
			printf("Not support set dimmer a upnp device via ubus service.\n");
		}
		else
		{
			//service is not supported
			printf("Serivce %s is currently not supported.\n", type);
		}
	}
	else if (!strcmp(method,"get_binary"))
	{
		//call ubus to get binary
		if (!strcmp(type,"zigbee"))
		{
			//call ubus mehod to set binary for a zigbee device
			if(daemon_services[0].id != 0)
			{
				char* id = get_string_data(msg,ID);
				char* epnum = get_string_data(msg,EPNUM);
				char* proid = get_string_data(msg,PROID);
				printf("Start to get binary for zigbee device with id =%s.\n",id);
				blob_buf_init(&buff, 0);
				blobmsg_add_string(&buff, ID, id);
				blobmsg_add_string(&buff, EPNUM, epnum);
				blobmsg_add_string(&buff, PROID, proid);
				ubus_invoke_async(ctx, daemon_services[0].id, "get_binary", buff.head, &g_req);
				g_req.data_cb = recive_data_cb;
				g_req.complete_cb = complete_cb;
				ubus_complete_request_async(ctx, &g_req);
			}
			else
			{
				//cannot find zigbee ubus service to call
				printf("Cannot find zigbee service on ubus daemon.\n");
			}
		}
		else if (!strcmp(type,"zwave"))
		{
			//call ubus mehod to get binary for a z-wave device
			if(daemon_services[1].id != 0)
			{
				char* id = get_string_data(msg,ID);
				printf("Start to set_binary for z-wave device with id = %s.\n",id);
				blob_buf_init(&buff, 0);
				blobmsg_add_string(&buff, ID, id);
				ubus_invoke_async(ctx, daemon_services[1].id, "set_binary", buff.head, &g_req);
				g_req.data_cb = recive_data_cb;
				g_req.complete_cb = complete_cb;
				ubus_complete_request_async(ctx, &g_req);
			}
			else
			{
				//cannot find zigbee ubus service to call
				printf("Cannot find zwave service on ubus daemon.\n");
			}
		}
		else if (!strcmp(type,"upnp"))
		{
			if(daemon_services[2].id != 0)
			{
				char* id = get_string_data(msg,ID);
				char* value = get_string_data(msg,VALUE);
				printf("Start to get_binary for upnp device with id = %s.\n",id);
				blob_buf_init(&buff, 0);
				blobmsg_add_string(&buff, ID, id);
				blobmsg_add_string(&buff, VALUE, value);
				ubus_invoke_async(ctx, daemon_services[2].id, "get_binary", buff.head, &g_req);
				g_req.data_cb = recive_data_cb;
				g_req.complete_cb = complete_cb;
				ubus_complete_request_async(ctx, &g_req);
			}
			else
			{
				//cannot find upnp ubus service to call
				printf("Cannot find upnp service on ubus daemon.\n");
			}
		}
		else
		{
			//service is not supported
			printf("Serivce %s is currently not supported.\n", type);
		}
	}
	else if (!strcmp(method,"reset"))
	{
		//call ubus to reset
		if (!strcmp(type,"zigbee"))
		{
			//call ubus mehod to reset zigbee controller
			if(daemon_services[0].id != 0)
			{
				printf("Start to reset zigbee controller.\n");
				ubus_invoke_async(ctx, daemon_services[0].id, "reset", NULL, &g_req);
				g_req.data_cb = recive_data_cb;
				g_req.complete_cb = complete_cb;
				ubus_complete_request_async(ctx, &g_req);
			}
			else
			{
				//cannot find zigbee ubus service to call
				printf("Cannot find zigbee service on ubus daemon.\n");
			}
		}
		else if (!strcmp(type,"zwave"))
		{
			//call ubus mehod to list z-wave devices
			if (daemon_services[1].id != 0)
			{
				printf("Start to reset z-wave controller.\n");
				ubus_invoke_async(ctx, daemon_services[1].id, "reset", NULL, &g_req);
				g_req.data_cb = recive_data_cb;
				g_req.complete_cb = complete_cb;
				ubus_complete_request_async(ctx, &g_req);
			}
			else
			{
				//cannot find zigbee ubus service to call
				printf("Cannot find zwave service on ubus daemon.\n");
			}
		}
		else if (!strcmp(type,"upnp"))
		{
			//Not support reset upnp via ubus service
			printf("Not support reset upnp via ubus service.\n");
		}
		else
		{
			//service is not supported
			printf("Serivce %s is currently not supported.\n", type);
		}
	}
	else
	{
		//not supported method
		printf("Currently not support method: %s\n",method);
	}

}

void start_service(void)
{
	int i;
	int rc =0;	
	int port;
	char* clientID;
	char* host;
//	char* topic;

	//read configuration
	clientID =  read_option("remote.access.clientId");
	// FIXME: It should be customize 
	//host = read_option("remote.access.host");
	host = calloc(1, 256);
	strcpy(host, "52.88.81.183");


	//topic = read_option("remote.access.topic");
	
	// FIXME: It should get from configuration 
	//port = atoi((char*) read_option("remote.access.port"));
	port = 1883;

	remote_service_init();

	printf("Read config: clientID = %s, host = %s, port = %d, topic = %s\n",clientID,host,port,g_remote_sevice.topic);

	signal(SIGINT, handle_signal);
	signal(SIGTERM, handle_signal);

	mosquitto_lib_init();


	mosq = mosquitto_new((const char*) clientID, true, NULL);

	if(mosq){
		mosquitto_connect_callback_set(mosq, connect_callback);
		mosquitto_message_callback_set(mosq, message_callback);


		rc = mosquitto_connect(mosq,(const char*) host, port, 60);
		printf("Connect to mosquitto server with result = %d\n", rc);

		mosquitto_subscribe(mosq, NULL,(const char*) g_remote_sevice.topic, 0);
		
		rc = mosquitto_loop_start(mosq);
		
		//init ubus service
		rc = init_ubus_service(&ctx);
		if(ctx)
		{
			for (i = 0; i < sizeof(daemon_services)/sizeof(daemon_service); i++) 
			{
				if(ubus_lookup_id(ctx, daemon_services[i].name, &daemon_services[i].id)) 
	            { //find service handler
	            	fprintf(stderr, "Failed to look up %s object\n", daemon_services[i].name);
	            }
	            else
	            {
	            	printf("Success to look up %s object\n", daemon_services[i].name);
	            }
        	}
		}
		printf("Started ubus serivce with result = %d\n", rc);
		client_main(&ctx, &main_object, &main_event);

		//free data
		free(clientID);
		free(host);
		//free(topic);
	}
}
