/******************************************************************************
 * Copyright (c) 2014, VEriK Systems. All rights reserved.
 *
 * Module: Remote Access
 *
 ******************************************************************************/

#include "remote_service.h"


int main(int argc, char *argv[])
{
	//start remote service
	start_service();

	return 0;
}

